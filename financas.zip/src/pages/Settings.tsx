import { Box, Typography } from '@mui/material';

export default function Settings() {
  return (
    <Box sx={{ backgroundColor: 'red' }}>
      <Typography variant="h4">Settings</Typography>
      <Box>e</Box>
    </Box>
  );
}
