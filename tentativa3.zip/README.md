## Projeto base ReactJS

- Projeto base RectJS com as seguintes configurações:
  - Redux
  - Axios
  - Tema
  - Eslint
  - Prettier
  - CommitLint
  - Husky
  - Lintstaged
  - Estrutura de pastas

  ## Páginas

  - Inicio
  - Clientes
  - Cartões
  - Settings